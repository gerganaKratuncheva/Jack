using UnityEngine;
using System.Collections;

namespace UnityEngine.Advertisements.XCodeEditor
{
	public class XCFileOperationQueue : System.IDisposable
	{
		public void Dispose()
		{

		}
	}
}
