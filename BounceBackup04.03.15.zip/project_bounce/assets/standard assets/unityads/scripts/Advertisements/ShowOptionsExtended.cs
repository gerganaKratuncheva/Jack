﻿namespace UnityEngine.Advertisements.Optional {
  using System;

  public class ShowOptionsExtended : ShowOptions {
    
    public string gamerSid { get; set; }
    
  }
  
}
