﻿#pragma strict

function Start () {

}

function Update () {

}